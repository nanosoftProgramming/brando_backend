<?php

return [
    'name' => 'Restaurant',
];
