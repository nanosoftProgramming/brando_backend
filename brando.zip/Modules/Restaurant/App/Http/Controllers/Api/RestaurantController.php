<?php

namespace Modules\Restaurant\App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Restaurant\Service\RestaurantService;
use Modules\Restaurant\App\resources\RestaurantResource;

class RestaurantController extends Controller
{
    private $restaurantService;
    public function __construct(RestaurantService $restaurantService)
    {
        $this->restaurantService = $restaurantService;
    }
    public function index(Request $request)
    {
        $data = $request->all();
        $relations = [];
        $restaurants = $this->restaurantService->active($data, $relations);
        return returnMessage(true, 'Restaurants Fetched Successfully', RestaurantResource::collection($restaurants)->response()->getData(true));
    }

    public function getByCategory(Request $request, $category)
    {
        $data = $request->all();
        $relations = [];
        $restaurants = $this->restaurantService->getByCategory($category, $data, $relations);
        return returnMessage(true, 'Restaurants Fetched Successfully', RestaurantResource::collection($restaurants)->response()->getData(true));
    }
}
