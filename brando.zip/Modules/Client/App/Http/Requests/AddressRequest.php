<?php

namespace Modules\Client\App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddressRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // لو في صلاحيات معينة، تقدر تضيفها هنا لاحقاً
    }

    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            'city_id' => 'required|exists:cities,id',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'block' => 'nullable|string|max:255',
            'street' => 'nullable|string|max:255',
            'house_number' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
            'default' => 'nullable|boolean',
            'phone' => 'required',
        ];
    }

   
}
