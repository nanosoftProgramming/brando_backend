<?php

namespace Modules\Client\Service;

use Modules\Client\App\Models\Address;
use Modules\Client\App\Models\Phone;

class AddressService
{
    public function findAll($filters = [])
    {
        return Address::with(['city', 'client', 'phone'])->latest()->get();
    }

    public function create(array $data)
    {
        $data['client_id'] = auth('client')->user()->id;
        $phone = Phone::firstOrCreate(
            ['phone' => $data['phone']],
            ['client_id' => $data['client_id']] 
        );

        $data['phone_id'] = $phone->id;
        unset($data['phone']);

        return Address::create($data);
    }

    public function update(Address $address, array $data)
    {
        $data['client_id'] = auth('client')->user()->id;

        if (isset($data['phone'])) {
            $phone = Phone::firstOrCreate(
                ['phone' => $data['phone']],
                ['client_id' => $data['client_id']]
            );
            $data['phone_id'] = $phone->id;
            unset($data['phone']);
        }

        $address->update($data);
        return $address;
    }

    public function delete(Address $address)
    {
        return $address->delete();
    }
}
