<?php

namespace Modules\Product\App\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'restaurant' => $this->restaurant->name ?? null,
            'category' => $this->category->name ?? null,
            'code' => $this->code ?? null,
            'name' => $this->name ?? null,
            'description' => $this->description,
            'price_egp' => $this->price_egp ?? null,
            'price_sar' => $this->price_sar ?? null,
            'discounted_price_egp' => $this->discounted_price_egp ?? 0,
            'discounted_price_sar' => $this->discounted_price_sar ?? 0,
            'is_active' => $this->is_active,
            "created_at" => $this->created_at ? $this->created_at->format('Y-m-d') : null,
            "updated_at" => $this->updated_at ? $this->updated_at->format('Y-m-d') : null,
            'addons' => $this->whenLoaded('addons'),
            'images' => $this->whenLoaded('images'),
            'attributes' => $this->whenLoaded('attributeValues'),
        ];
    }
}
