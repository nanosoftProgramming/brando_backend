<?php 
namespace Modules\Product\App\Http\Controllers\Api;

use Exception;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Modules\Product\Service\BranchProductService;
use Modules\Product\App\Http\Requests\BranchProductRequest;
use Modules\Product\App\Models\BranchProduct;
use Modules\Product\App\Resources\BranchProductResource;
use Illuminate\Http\Request;

class BranchProductController extends Controller
{
    protected $branchProductService;

    public function __construct(BranchProductService $branchProductService)
    {
 
        $this->middleware(middleware: 'auth:client');
        $this->branchProductService = $branchProductService;
    }

   
    public function index(Request $request, $branchId)
    {
        $filters = $request->all();  
        $products = $this->branchProductService->getByBranch($branchId, $filters);
        return returnMessage(true, 'Branch Products fetched successfully', BranchProductResource::collection($products)->response()->getData(true));
    }
    

}
