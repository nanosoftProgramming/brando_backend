<?php
namespace Modules\Product\App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Product\Service\ProductService;
use Modules\Product\App\Resources\ProductResource;

class ProductController extends Controller
{
    protected $productService;

    public function __construct(ProductService $productService)
    {
        $this->productService = $productService;
    }

    public function index(Request $request)
    {
        $data = $request->all();
        $relations = ['addons', 'attributeValues.attribute', 'attributeValues.value'];
        $products = $this->productService->active($data, $relations);
        return returnMessage(true, 'Products fetched successfully', $products);
    }

    public function getByRestaurant(Request $request, $restaurant)
    {
        $data = $request->all();
        $relations = ['addons', 'attributeValues.attribute', 'attributeValues.value'];
        $products = $this->productService->getByRestaurant($restaurant, $data, $relations);
        return returnMessage(true, 'Products fetched successfully', $products);
    }


}
