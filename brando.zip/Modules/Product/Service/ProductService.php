<?php

namespace Modules\Product\Service;

use Illuminate\Support\Facades\File;
use Modules\Product\App\Models\Product;
use Modules\Common\Helpers\UploadHelper;
use Modules\Product\App\Models\ProductImage;
use Modules\Product\App\Models\AttributeValue;

class ProductService
{
    use UploadHelper;
    public function findAll($data = [], $relations = [])
    {
        $query = Product::query()
            ->available()
            ->with($relations)
            ->filter($data)
            ->orderByDesc('created_at');

        return getCaseCollection($query, $data);
    }

    public function active($data = [], $relations = [])
    {
        $query = Product::query()
            ->active()
            ->available()
            ->with($relations)
            ->filter($data)
            ->orderByDesc('created_at');

        return getCaseCollection($query, $data);
    }
    public function create(array $data)
    {

        if (request()->hasFile('image')) {
            $data['image'] = $this->upload(request()->file('image'), 'products');
        }

        $product = Product::create($data);

        if (isset($data['addons']) && !empty($data['addons'])) {
            $addonIds = array_column($data['addons'], 'addon_id');
            $product->addons()->sync($addonIds);
        }
        if (isset($data['attributes']) && !empty($data['attributes'])) {
            foreach ($data['attributes'] as $attribute) {
                $product->attributeValues()->create([
                    'attribute_id' => $attribute['attribute_id'],
                    'attribute_value_id' => $attribute['attribute_value_id'],
                    'price_egp' => $attribute['price_egp'],
                    'price_sar' => $attribute['price_sar'],
                ]);
            }
        }
        // if (isset($data['attributes']) && !empty($data['attributes'])) {
        //     foreach ($data['attributes'] as $attribute) {
        //         $productAttribute = ProductAttribute::create([
        //             'name' => $attribute['name'],
        //             'required' => $attribute['required'] ?? false,
        //             'multi_select' => $attribute['multi_select'] ?? false,
        //             'override_price' => $attribute['override_price'] ?? false,
        //             'product_id' => $product->id,
        //         ]);

        //         if (isset($attribute['values']) && !empty($attribute['values'])) {
        //             foreach ($attribute['values'] as $value) {
        //                 ProductAttributeValue::create([
        //                     'attribute_value' => $value['attribute_value'],
        //                     'price_egp' => $value['price_egp'] ?? 0,
        //                     'price_sar' => $value['price_sar'] ?? 0,
        //                     'product_attribute_id' => $productAttribute->id,
        //                 ]);
        //             }
        //         }
        //     }
        // }

        if (isset($data['images']) && !empty($data['images'])) {
            foreach ($data['images'] as $image) {
                $imagePath = $this->upload($image, 'products');
                ProductImage::create([
                    'product_id' => $product->id,
                    'image' => $imagePath,
                ]);
            }
        }

        return $product->fresh()->load(['addons', 'images', 'restaurant', 'category', 'attributeValues.attribute', 'attributeValues.value']);
    }
    public function update(Product $product, array $data)
    {
        if (request()->hasFile('image')) {
            File::delete(public_path('uploads/products/' . $this->getImageName('products', $product->image)));
            $data['image'] = $this->upload(request()->file('image'), 'products');
        }
        $product->update($data);
        if (isset($data['addons']) && !empty($data['addons'])) {
            $product->addons()->sync($data['addons']);
        }
        if (isset($data['attributes']) && !empty($data['attributes'])) {
            $attributeIds = array_column($data['attributes'], 'attribute_id');
            $product->attributes()->sync($attributeIds);
        }
        return $product->fresh()->load('addons', 'attributes.values');
    }

    public function findById($id)
    {
        return Product::with(['restaurant', 'category'])->findOrFail($id);
    }
    public function delete(Product $product)
    {
        return $product->delete();
    }
    function activate($id)
    {
        $product = $this->findById($id);
        $product->is_active = !$product->is_active;
        $product->save();
    }

    public function getByRestaurant($restaurantId, $data = [], $relations = [])
    {
        $query = Product::query()
            ->where('restaurant_id', $restaurantId)
            ->active()
            ->with($relations)
            ->filter($data)
            ->orderByDesc('created_at');
        return getCaseCollection($query, $data);
    }
}
