<?php

namespace Modules\Order\DTO;

class OrderDto
{
    public $address_id;
    public $branch_id;
    public $payment_type;
    public $status_id;

    public $total;

    public $sub_total;

    public $taxes;
    public function __construct($request)
    {
        if ($request->get('address_id'))
            $this->address_id = $request->get('address_id');

        if ($request->get('branch_id'))
            $this->branch_id = $request->get('branch_id');

        if ($request->get('payment_type'))
            $this->payment_type = $request->get('payment_type');

        if ($request->get('status_id'))
            $this->status_id = $request->get('status_id');
        if ($request->get('total'))
            $this->total = $request->get('total');
        if ($request->get('sub_total'))
            $this->sub_total = $request->get('sub_total');
        if ($request->get('taxes'))
            $this->taxes = $request->get('taxes');          

    }

    public function dataFromRequest()
    {
        $data = json_decode(json_encode($this), true);

        if ($this->address_id == null)
            unset($data['address_id']);

        if ($this->branch_id == null)
            unset($data['branch_id']);

        if ($this->payment_type == null)
            unset($data['payment_type']);

        if ($this->status_id == null)
            unset($data['status_id']);
        if ($this->total == null)   
            unset($data['total']);
        if ($this->sub_total == null)
            unset($data['sub_total']);
        if ($this->taxes == null)
        unset($data['taxes']);

        return $data;
    }
}
