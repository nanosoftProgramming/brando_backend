<?php

namespace Modules\Order\Service;

use Modules\Order\App\Models\Order;
use Modules\Order\App\Models\OrderItem;
use Modules\Client\App\Models\Phone;
use Modules\Client\App\Models\Address;
use Modules\Cart\App\Models\Cart;
use Modules\Cart\App\Models\CartItem;
use Illuminate\Support\Facades\DB;
use Modules\Order\App\Models\OrderStatus;
use Exception;

class OrderService
{
    public function getAllOrders($clientId)
    {
        return Order::with([
            'items.branch_product.product',
            'address',
            'branch',
            'status'
        ])
            ->where('client_id', $clientId)
            ->latest()
            ->get();
    }
    public function findAll($filters = [])
    {
        return Order::with([
            'items.branch_product.product',
            'branch',
            'address',
            'client',
            'status'
        ])->filter($filters)->latest()->get();
    }


    public function create($data)
    {
        return DB::transaction(function () use ($data) {
            $clientId = auth('client')->id();

            $address = Address::findOrFail($data['address_id']);
            $phone = Phone::findOrFail($address->phone_id);

            if (!$phone->is_verified) {
                throw new Exception("Phone not verified. Verification code sent.");
            }

            $cart = Cart::where('client_id', $clientId)->first();

            if (!$cart) {
                throw new Exception("Cart not found.");
            }

            $branchId = $data['branch_id'];

            $cartItems = CartItem::where('cart_id', $cart->id)
                ->whereHas('branchProduct', function ($query) use ($branchId) {
                    $query->where('branch_id', $branchId);
                })
                ->with('branchProduct.product')
                ->get();

            if ($cartItems->isEmpty()) {
                throw new Exception("No cart items found for the selected branch.");
            }

            $subTotal = $cartItems->sum(function ($item) {
                return $item->price * $item->quantity;
            });

            $taxRate = 0.15;
            $taxes = $subTotal * $taxRate;

            $total = $subTotal + $taxes;
            $status = OrderStatus::where('name', 'pending')->firstOrFail();

            $order = Order::create([
                'client_id' => $clientId,
                'branch_id' => $branchId,
                'address_id' => $data['address_id'],
                'payment_type' => $data['payment_type'],
                'status_id' => $status->id,
                'sub_total' => $subTotal,
                'taxes' => $taxes,
                'total' => $total,
            ]);

            foreach ($cartItems as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->branchProduct->product_id,
                    'branch_product_id' => $item->branchProduct->id,
                    'quantity' => $item->quantity,
                    'price' => $item->price,
                    'total' => $item->price * $item->quantity,
                ]);
            }

            CartItem::whereIn('id', $cartItems->pluck('id'))->delete();

            return $order;
        });
    }

}
