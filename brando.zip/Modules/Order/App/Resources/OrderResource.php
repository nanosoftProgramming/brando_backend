<?php

namespace Modules\Order\App\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
         'status' => optional($this->status)->name,
            'payment_type' => $this->payment_type,
            'total_items'  => $this->items->count(),
            'total_price'  => $this->total,
            'sub_total'    => $this->sub_total,
            'taxes'        => $this->taxes,

            'branch'       => optional($this->branch)->name,
            'address'      => [
                'title'        => optional($this->address)->title,
                'block'        => optional($this->address)->block,
                'street'       => optional($this->address)->street,
                'house_number' => optional($this->address)->house_number,
            ],
            'items' => $this->items->map(function ($item) {
                return [
                    'product'  => optional($item->branch_product->product)->name,
                  

                    'quantity' => $item->quantity,
                    'price'    => $item->price,
                    'total'    => $item->total,
                ];
            }),
            'created_at' => $this->created_at->format('Y-m-d h:i A'),

        ];
    }
}
