<?php
namespace Modules\Order\App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Client\App\Models\Client;   
use Modules\Client\App\Models\Address;
use Modules\Order\App\Models\OrderItem;
use Modules\Branch\App\Models\Branch;
use Spatie\Activitylog\LogOptions;
use Modules\Order\App\Models\OrderStatus;
use Modules\Driver\App\Models\Driver;
class Order extends Model
{
    use HasFactory;
    protected $fillable = [
        'client_id',
        'branch_id',
        'address_id',
        'payment_type',
        'status_id',
        'total',
        'sub_total',
        'taxes',
        'driver_id'
    ];
    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logAll()
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs()
            ->useLogName('Order')
            ->dontLogIfAttributesChangedOnly(['updated_at']);
    }
   
    
    protected function serializeDate(\DateTimeInterface $date)
    {
        return $date->format('Y-m-d h:i A');
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }


    public function items()
{
    return $this->hasMany(OrderItem::class);
}

public function address()
{
    return $this->belongsTo(Address::class);
}

public function branch()
{
    return $this->belongsTo(Branch::class);
}

public function scopeAvailable($query)
{\Log::info('Admin: ', ['admin' => auth('admin')->user()]);

    if (auth('admin')->check()) {
        $admin = auth('admin')->user();

        if ($admin->hasRole('Super Admin')) {
        } elseif ($admin->hasRole('Restaurant Manager')) {
            $query->whereHas('branch', function ($q) use ($admin) {
                $q->where('restaurant_id', $admin->restaurant_id);
            });
        } elseif ($admin->hasRole('Branch Manager')) {
            $query->where('branch_id', $admin->branch_id);
        }
    }

    return $query;
}

public function driver()
{
    return $this->belongsTo(Driver::class);
}
public function scopeFilter($query, $filters)
{
    if (!empty($filters['status_id'])) {
        $query->where('status_id', $filters['status_id']);
    }
    

    if (!empty($filters['branch_name'])) {
        $query->whereHas('branch', function ($q) use ($filters) {
            $q->where('name', 'like', '%' . $filters['branch_name'] . '%');
        });
    }
    if(!empty($filters['client_name'])) {
        $query->whereHas('client', function ($q) use ($filters) {
            $q->where('name', 'like', '%' . $filters['client_name'] . '%');
        });
    }
   
    if (!empty($filters['created_at'])) {
        $query->whereDate('created_at', $filters['created_at']);
    }
    if (!empty($filters['status_name'])) {
        $query->whereHas('status', function ($q) use ($filters) {
            $q->where('name', 'like', '%' . $filters['status_name'] . '%');
        });
    }
    if (!empty($filters['payment_type'])) {
        $query->where('payment_type', $filters['payment_type']);
    }
    if (!empty($filters['total'])) {
        $query->where('total', $filters['total']);
    }
    if (!empty($filters['client_id'])) {
        $query->where('client_id', $filters['client_id']);
    }
    if (!empty($filters['branch_id'])) {
        $query->where('branch_id', $filters['branch_id']);
    }
    if (!empty($filters['address_id'])) {
        $query->where('address_id', $filters['address_id']);
    }

    return $query;
}
public function status()
{
    return $this->belongsTo(OrderStatus::class, 'status_id');
}
}
