<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->decimal('sub_total', 10, 2)->default(0.00)->after('payment_type');
            $table->decimal('taxes', 10, 2)->default(0.00)->after('sub_total');
            $table->decimal('total', 10, 2)->default(0.00)->after('taxes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['sub_total', 'taxes', 'total']);
        });
    }
};
