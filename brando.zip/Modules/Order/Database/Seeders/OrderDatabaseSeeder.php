<?php

namespace Modules\Order\Database\Seeders;
use Modules\Order\Database\Seeders\OrderStatusSeeder;
use Illuminate\Database\Seeder;

class OrderDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call([
        ]);
    }
    
}
