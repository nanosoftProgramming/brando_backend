<?php

namespace Modules\Order\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OrderStatusSeeder extends Seeder
{
    
    public function run(): void
    {

        DB::table('order_statuses')->insert([
            ['name' => 'Pending',     'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Confirmed',   'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Processing',  'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Shipped',     'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Delivered',   'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Cancelled',   'created_at' => now(), 'updated_at' => now()],
        ]);
    }
}
