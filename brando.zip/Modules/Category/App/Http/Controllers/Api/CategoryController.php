<?php

namespace Modules\Category\App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Category\Service\CategoryService;
use Modules\Restaurant\App\Models\Restaurant;
use Modules\Category\App\resources\CategoryResource;

class CategoryController extends Controller
{
    private $categoryService;
    public function __construct(CategoryService $categoryService)
    {
        $this->categoryService = $categoryService;
    }

    public function index(Request $request)
    {
        $data = $request->all();
        $relations = ['childrenRecursive'];
        $categories = $this->categoryService->active($data, $relations);
        return returnMessage(true, 'Categories Fetched Successfully', CategoryResource::collection($categories)->response()->getData(true));
    }

    public function getByRestaurant(Request $request, Restaurant $restaurant)
    {
        $data = $request->all();
        $categories = $this->categoryService->getByRestaurant($restaurant, $data);
        return returnMessage(true, 'Categories Fetched Successfully', CategoryResource::collection($categories)->response()->getData(true));
    }
}