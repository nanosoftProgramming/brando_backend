<?php
namespace Modules\Cart\App\Models;

use Modules\Cart\App\Models\Cart;
use Modules\Cart\App\Models\CartItemAddon;
use Modules\Cart\App\Models\CartItemAttribute;
use Spatie\Activitylog\LogOptions;
use Illuminate\Database\Eloquent\Model;
use Modules\Product\App\Models\Product;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CartItem extends Model
{
    use HasFactory;

    protected $fillable = ['cart_id', 'quantity', 'product_id', 'notes'];


    protected $appends = [
        'unit_price_egp',
        'unit_price_sar',
        'discounted_price_egp',
        'discounted_price_sar',
        'total_price_egp',
        'total_price_sar',
        'subtotal_egp',
        'subtotal_sar',
        'discounted_subtotal_egp',
        'discounted_subtotal_sar',
        'addons_total_egp',
        'addons_total_sar'
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logAll()
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs()
            ->useLogName('CartItem')
            ->dontLogIfAttributesChangedOnly(['updated_at']);
    }

    protected function serializeDate(\DateTimeInterface $date)
    {
        return $date->format('Y-m-d h:i A');
    }

    public function cart()
    {
        return $this->belongsTo(Cart::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function addons()
    {
        return $this->hasMany(CartItemAddon::class);
    }

    public function attributes()
    {
        return $this->hasMany(CartItemAttribute::class);
    }


    public function getUnitPriceEgpAttribute()
    {
        if (!$this->product) {
            return 0;
        }

        return $this->product->price_egp;
    }

    public function getUnitPriceSarAttribute()
    {
        if (!$this->product) {
            return 0;
        }

        return $this->product->price_sar;
    }


    /**
     * Calculate subtotal in EGP (product price × quantity + attributes, no addons)
     * ALWAYS uses regular price
     */
    public function getSubtotalEgpAttribute()
    {
        return ($this->unit_price_egp + $this->calculateAttributePrice('egp')) * $this->quantity;
    }


    /**
     * Calculate subtotal in SAR (product price × quantity + attributes, no addons)
     * ALWAYS uses regular price
     */
    public function getSubtotalSarAttribute()
    {
        return ($this->unit_price_sar + $this->calculateAttributePrice('sar')) * $this->quantity;
    }

    public function getAddonsTotalEgpAttribute()
    {
        return $this->addons->sum(function ($addon) {
            return $addon->total_price_egp ?? 0;
        });
    }

    public function getAddonsTotalSarAttribute()
    {
        return $this->addons->sum(function ($addon) {
            return $addon->total_price_sar ?? 0;
        });
    }

    /**
     * Calculate total price in EGP (uses best available price + addons)
     * SMART - uses discounted if available, otherwise regular
     */
    public function getTotalPriceEgpAttribute()
    {
        $effectiveSubtotal = $this->discounted_price_egp > 0
            ? $this->discounted_subtotal_egp
            : $this->subtotal_egp;

        return $effectiveSubtotal + $this->addons_total_egp;
    }

    /**
     * Calculate total price in SAR (uses best available price + addons)
     * SMART - uses discounted if available, otherwise regular
     */
    public function getTotalPriceSarAttribute()
    {
        $effectiveSubtotal = $this->discounted_price_sar > 0
            ? $this->discounted_subtotal_sar
            : $this->subtotal_sar;

        return $effectiveSubtotal + $this->addons_total_sar;
    }

    public function getDiscountedPriceEgpAttribute()
    {
        if (!$this->product) {
            return 0;
        }

        return $this->product->discounted_price_egp ?? 0;
    }


    public function getDiscountedPriceSarAttribute()
    {
        if (!$this->product) {
            return 0;
        }

        return $this->product->discounted_price_sar ?? 0;
    }

    public function getDiscountedSubtotalEgpAttribute()
    {
        $effectivePrice = $this->discounted_price_egp > 0 ? $this->discounted_price_egp : $this->unit_price_egp;
        return ($effectivePrice + $this->calculateAttributePrice('egp')) * $this->quantity;
    }


    public function getDiscountedSubtotalSarAttribute()
    {
        $effectivePrice = $this->discounted_price_sar > 0 ? $this->discounted_price_sar : $this->unit_price_sar;
        return ($effectivePrice + $this->calculateAttributePrice('sar')) * $this->quantity;
    }


    /**
     * Calculate attribute price for given currency
     */
    private function calculateAttributePrice($currency)
    {
        return $this->attributes()->with('attributeValue')->get()->sum(function ($attribute) use ($currency) {
            return $attribute->attributeValue->{"price_{$currency}"} ?? 0;
        });
    }
}
