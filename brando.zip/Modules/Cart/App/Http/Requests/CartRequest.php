<?php

namespace Modules\Cart\App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use Modules\Product\App\Models\Product;
use Modules\Product\App\Models\Addon;
use Modules\Product\App\Models\ProductAttributeValue;

class CartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        // Check if this is an update request by checking if cart_item_id exists in route
        $cartItemId = $this->route('cartItem') || $this->route('cart_item_id');
        $isUpdate = !empty($cartItemId);

        $rules = [
            'quantity' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'notes' => ['nullable', 'string', 'max:500'],

            'addons' => ['sometimes', 'array'],
            'addons.*.addon_id' => [
                'required',
                'exists:addons,id',
                'distinct'
            ],
            'addons.*.quantity' => ['required', 'integer', 'min:1', 'max:10'],

            'attributes' => ['sometimes', 'array'],
            'attributes.*' => [
                'required',
                'exists:product_attribute_values,id',
                'distinct'
            ],
        ];

        // Only require product_id for CREATE requests (no cart_item_id in route)
        if (!$isUpdate) {
            $rules['product_id'] = ['required', 'exists:products,id'];
            $rules['quantity'] = ['required', 'integer', 'min:1', 'max:100'];
        }

        return $rules;
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'product_id.required' => 'Product selection is required',
            'product_id.exists' => 'Selected product does not exist',
            'quantity.required' => 'Quantity is required',
            'quantity.min' => 'Quantity must be at least 1',
            'quantity.max' => 'Maximum quantity allowed is 100',
            'addons.*.addon_id.required' => 'Addon selection is required',
            'addons.*.addon_id.exists' => 'Selected addon does not exist',
            'addons.*.addon_id.distinct' => 'Duplicate addons are not allowed',
            'addons.*.quantity.required' => 'Addon quantity is required',
            'addons.*.quantity.min' => 'Addon quantity must be at least 1',
            'addons.*.quantity.max' => 'Maximum addon quantity allowed is 10',
            'attributes.*.required' => 'Attribute selection is required',
            'attributes.*.exists' => 'Selected attribute value does not exist',
            'attributes.*.distinct' => 'Duplicate attribute values are not allowed',
        ];
    }

    /**
     * Configure the validator instance.
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            // Only validate product relationships for CREATE requests
            $cartItemId = $this->route('cartItem') || $this->route('cart_item_id');
            $isUpdate = !empty($cartItemId);

            if (!$isUpdate) {
                $this->validateProductRelationships($validator);
            }
        });
    }

    /**
     * Validate that addons and attributes belong to the selected product
     */
    private function validateProductRelationships($validator)
    {
        $productId = $this->input('product_id');

        if (!$productId) {
            return;
        }

        $product = Product::with(['addons', 'attributes.values'])->find($productId);

        if (!$product) {
            return;
        }

        // Validate addons
        if ($this->has('addons')) {
            $validAddonIds = $product->addons->pluck('id')->toArray();

            foreach ($this->input('addons', []) as $index => $addonData) {
                if (isset($addonData['addon_id']) && !in_array($addonData['addon_id'], $validAddonIds)) {
                    $validator->errors()->add("addons.{$index}.addon_id", 'The selected addon does not belong to this product.');
                }

                // Check if addon is active
                if (isset($addonData['addon_id'])) {
                    $addon = \Modules\Product\App\Models\Addon::find($addonData['addon_id']);
                    if ($addon && !$addon->is_active) {
                        $validator->errors()->add("addons.{$index}.addon_id", 'The selected addon is not available.');
                    }
                }
            }
        }

        // Validate attributes
        if ($this->has('attributes')) {
            $validAttributeValueIds = $product->attributes
                ->flatMap->values
                ->pluck('id')
                ->toArray();

            foreach ($this->input('attributes', []) as $index => $attributeValueId) {
                if (!in_array($attributeValueId, $validAttributeValueIds)) {
                    $validator->errors()->add("attributes.{$index}", 'The selected attribute value does not belong to this product.');
                }
            }
        }
    }

    /**
     * Handle a failed validation attempt.
     */
    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            returnMessage(false, 'Validation failed', $validator->errors(), 'validation_error')
        );
    }
}
