<?php

namespace Modules\Common\Service;

use Modules\Product\App\Models\Product;
use Modules\Category\App\Models\Category;
use Modules\Branch\App\Models\Branch;
use Modules\Restaurant\App\Models\Restaurant;
use Modules\Product\App\Models\Addon;
use Modules\Product\App\Models\ProductAttribute;

class SearchService
{
    public function searchEverything(string $query, int $limit = 50)
    {
        $results = collect();

        $products = $this->searchProducts($query, $limit);
        $results = $results->merge($products);


        $categories = $this->searchCategories($query, $limit);
        $results = $results->merge($categories);


        $branches = $this->searchBranches($query, $limit);
        $results = $results->merge($branches);


        $restaurants = $this->searchRestaurants($query, $limit);
        $results = $results->merge($restaurants);


        $addons = $this->searchAddons($query, $limit);
        $results = $results->merge($addons);


        $attributes = $this->searchAttributes($query, $limit);
        $results = $results->merge($attributes);


        return $results->take($limit);
    }

    private function searchProducts(string $query, int $limit)
    {
        return Product::query()
            ->with(['category', 'restaurant', 'images'])
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('description', 'like', "%{$query}%")
                    ->orWhere('code', 'like', "%{$query}%");
            })
            ->active()
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'product',
                    'name' => $item->name,
                    'description' => $item->description,
                    'image' => $item->images?->first()?->image ?? null,
                    'price_egp' => $item->price_egp,
                    'price_sar' => $item->price_sar,
                    'category' => $item->category,
                    'restaurant' => $item->restaurant,
                    'is_active' => $item->is_active,
                ];
            });
    }

    private function searchCategories(string $query, int $limit)
    {
        return Category::query()
            ->with(['parent', 'products'])
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('description', 'like', "%{$query}%");
            })
            ->active()
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'category',
                    'name' => $item->name,
                    'description' => $item->description,
                    'image' => $item->image,
                    'parent' => $item->parent,
                    'products' => $item->products,
                    'is_active' => $item->is_active,
                ];
            });
    }

    private function searchBranches(string $query, int $limit)
    {
        return Branch::query()
            ->with(['restaurant', 'city'])
            ->where(function ($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('phone', 'like', "%{$query}%")
                    ->orWhere('street', 'like', "%{$query}%")
                    ->orWhere('block', 'like', "%{$query}%")
                    ->orWhere('building_number', 'like', "%{$query}%");
            })
            ->active()
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'branch',
                    'name' => $item->name,
                    'phone' => $item->phone,
                    'city' => $item->city,
                    'street' => $item->street,
                    'block' => $item->block,
                    'building_number' => $item->building_number,
                    'notes' => $item->notes,
                    'latitude' => $item->latitude,
                    'longitude' => $item->longitude,
                    'restaurant' => $item->restaurant,
                    'is_active' => $item->is_active,
                ];
            });
    }

    private function searchRestaurants(string $query, int $limit)
    {
        return Restaurant::query()
            ->where('name', 'like', "%{$query}%")
            ->active()
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'restaurant',
                    'name' => $item->name,
                    'image' => $item->image,
                    'min_time' => $item->min_time,
                    'max_time' => $item->max_time,
                    'is_active' => $item->is_active,
                ];
            });
    }

    private function searchAddons(string $query, int $limit)
    {
        return Addon::query()
            ->with(['restaurant'])
            ->where('name', 'like', "%{$query}%")
            ->active()
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'addon',
                    'name' => $item->name,
                    'price_egp' => $item->price_egp,
                    'price_sar' => $item->price_sar,
                    'restaurant' => $item->restaurant,
                    'is_active' => $item->is_active,
                ];
            });
    }

    private function searchAttributes(string $query, int $limit)
    {
        return ProductAttribute::query()
            ->with(['product', 'values'])
            ->where('name', 'like', "%{$query}%")
            ->limit($limit)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'type' => 'attribute',
                    'name' => $item->name,
                    'required' => $item->required,
                    'multi_select' => $item->multi_select,
                    'override_price' => $item->override_price,
                    'product' => $item->product,
                    'values_count' => $item->values->count(),
                    'values' => $item->values->map(function ($value) {
                        return [
                            'id' => $value->id,
                            'attribute_value' => $value->attribute_value,
                            'price_egp' => $value->price_egp,
                            'price_sar' => $value->price_sar,
                        ];
                    }),
                ];
            });
    }
}
