<?php

namespace Modules\Common\App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Common\Service\SearchService;
use Modules\Common\App\Http\Requests\SearchRequest;

class SearchController extends Controller
{
    protected $searchService;

    public function __construct(SearchService $searchService)
    {
        $this->searchService = $searchService;
    }

    public function search(SearchRequest $request)
    {
        try {
            $query = $request->get('query');
            $limit = $request->get('limit', 20);

            if (strlen(trim($query)) < 2) {
                return returnMessage(true, 'Search query too short', []);
            }
            $results = $this->searchService->searchEverything($query, $limit);
            $groupedResults = $results->groupBy('type')->map(function ($items, $type) {
                return [
                    'count' => $items->count(),
                    'items' => $items->values()
                ];
            });

            return returnMessage(
                true,
                'Search completed successfully',
                ['total_results' => $results->count(), 'query' => $query, 'results' => $groupedResults]
            );

        } catch (\Exception $e) {
            return returnMessage(false, 'Search failed: ' . $e->getMessage(), null, 'server_error');
        }
    }
}
